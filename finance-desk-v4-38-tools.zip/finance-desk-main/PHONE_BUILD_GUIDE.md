# Finance Desk APK — browser-only Android guide

No command line, Termux, laptop or Android Studio is required. GitHub compiles the APK in the cloud.

## What is prepared

- Complete PWA and Android source
- 38 offline tools with automated tests
- Android package: `com.chitranjansharma.financedesk`
- Android SDK target 36 and minimum SDK 24
- Native launcher icons, splash, back-button handling and haptics

## 1. Create the repository

1. Open `github.com` in Chrome and sign in.
2. Open **Your repositories → New**.
3. Name it `finance-desk-android`.
4. Choose **Private** and do not add a README, licence or `.gitignore`.
5. Tap **Create repository**.

## 2. Upload the complete ZIP without extracting it

1. On the empty repository page, tap **uploading an existing file**.
2. Select `finance-desk-main.zip` from Downloads.
3. Enter `Upload Finance Desk application` as the commit message.
4. Tap **Commit changes**.

## 3. Create the cloud APK builder

1. Tap **Add file → Create new file**.
2. In the filename box enter `.github/workflows/build-apk.yml` exactly.
3. Paste the following into the large editor:

```yaml
name: Build Finance Desk APK

on:
  workflow_dispatch:

permissions:
  contents: read

jobs:
  build-apk:
    runs-on: ubuntu-latest
    timeout-minutes: 30
    steps:
      - name: Download repository
        uses: actions/checkout@v4
      - name: Extract source
        run: unzip -q finance-desk-main.zip
      - name: Set up Node
        uses: actions/setup-node@v4
        with:
          node-version: 22
      - name: Set up Java
        uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: 21
      - name: Set up Android
        uses: android-actions/setup-android@v3
      - name: Install Android SDK
        run: sdkmanager "platforms;android-36" "build-tools;36.0.0"
      - name: Install components and verify tools
        working-directory: finance-desk-main
        run: npm ci && npm test && npm run cap:sync
      - name: Build APK
        working-directory: finance-desk-main/android
        run: chmod +x gradlew && ./gradlew assembleDebug --no-daemon
      - name: Make APK available
        uses: actions/upload-artifact@v4
        with:
          name: finance-desk-apk
          path: finance-desk-main/android/app/build/outputs/apk/debug/app-debug.apk
          if-no-files-found: error
          retention-days: 30
```

4. Tap **Commit changes** twice.

## 4. Build and install

1. Open **Actions → Build Finance Desk APK**.
2. Tap **Run workflow → Run workflow**.
3. Wait for the green tick, open the completed run and download **finance-desk-apk** under **Artifacts**.
4. Extract that small artifact ZIP and install `app-debug.apk`.

This debug APK is for private testing. Before replacing it with a separately signed build, export saved profiles from **Tools → Private Data Vault**.
