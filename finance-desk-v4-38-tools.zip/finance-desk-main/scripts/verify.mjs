import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';

const root = resolve(import.meta.dirname, '..');
const html = await readFile(resolve(root, 'index.html'), 'utf8');
const manifest = JSON.parse(await readFile(resolve(root, 'manifest.webmanifest'), 'utf8'));
JSON.parse(await readFile(resolve(root, 'capacitor.config.json'), 'utf8'));

const scripts = [...html.matchAll(/<script(?:\s[^>]*)?>([\s\S]*?)<\/script>/gi)].map((m) => m[1]);
scripts.forEach((source, index) => {
  try { new Function(source); }
  catch (error) { throw new Error(`Inline script ${index + 1} has invalid JavaScript: ${error.message}`); }
});

const ids = [...html.matchAll(/\sid="([^"]+)"/g)].map((m) => m[1]);
const duplicates = ids.filter((id, index) => ids.indexOf(id) !== index);
if (duplicates.length) throw new Error(`Duplicate HTML ids: ${[...new Set(duplicates)].join(', ')}`);

const viewIds = new Set(ids.filter((id) => id.startsWith('v-')).map((id) => id.slice(2)));
const catalogueMatch = html.match(/const CATALOG=([\s\S]*?);\s*const TITLES/);
if (!catalogueMatch) throw new Error('Could not locate the calculator catalogue.');
const catalogueIds = [...catalogueMatch[1].matchAll(/\['([^']+)'/g)].map((m) => m[1]);
const missingViews = catalogueIds.filter((id) => !viewIds.has(id));
if (missingViews.length) throw new Error(`Catalogue entries missing views: ${missingViews.join(', ')}`);

if (!manifest.icons?.length || manifest.name !== 'Finance Desk — Advisor\'s Toolkit') {
  throw new Error('PWA manifest is missing its expected name or icons.');
}

new Function(await readFile(resolve(root, 'sw.js'), 'utf8'));
console.log(`Verified ${catalogueIds.length} tools, ${ids.length} unique ids, ${scripts.length} inline scripts and both JSON configs.`);
