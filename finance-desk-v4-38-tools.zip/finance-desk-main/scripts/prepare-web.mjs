import { cp, mkdir, rm } from 'node:fs/promises';
import { resolve } from 'node:path';

const root = resolve(import.meta.dirname, '..');
const out = resolve(root, 'www');
const files = [
  'index.html',
  'manifest.webmanifest',
  'sw.js',
  'apple-touch-icon.png',
  'favicon-16.png',
  'favicon-32.png',
  'icon-192.png',
  'icon-512.png',
  'icon-maskable-512.png'
];

await rm(out, { recursive: true, force: true });
await mkdir(out, { recursive: true });
await Promise.all(files.map((file) => cp(resolve(root, file), resolve(out, file))));
console.log(`Prepared ${files.length} web assets in ${out}`);
