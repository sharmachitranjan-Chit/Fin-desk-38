import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { JSDOM, VirtualConsole } from 'jsdom';

const root = resolve(import.meta.dirname, '..');
const html = await readFile(resolve(root, 'index.html'), 'utf8');
const virtualConsole = new VirtualConsole();
virtualConsole.on('jsdomError', (error) => {
  if (!String(error.message).includes('Not implemented: window.scrollTo')) throw error;
});

const dom = new JSDOM(html, {
  runScripts: 'dangerously',
  url: 'https://finance-desk.test/',
  virtualConsole
});
const { window } = dom;
window.scrollTo = () => {};
window.HTMLElement.prototype.scrollIntoView = () => {};

const set = (id, value) => { window.document.getElementById(id).value = String(value); };
const visible = (id) => window.document.getElementById(id).style.display === 'block';

set('amount', 4000000); set('rate', 8.4); set('term', 20);
window.calcEMI();
if (!window.document.getElementById('heroVal').textContent.includes('34,460')) {
  throw new Error(`Unexpected EMI result: ${window.document.getElementById('heroVal').textContent}`);
}

set('lhIncome', 150000); set('lhOblig', 10000); set('lhLoan', 5000000); set('lhProp', 7000000); set('lhRate', 8.4); set('lhYears', 20); set('lhSavings', 500000);
window.document.getElementById('lhCibil').value = '800';
window.calcLoanHealth();
const score = Number(window.document.getElementById('lhScore').textContent);
if (score < 70 || score > 100) throw new Error(`Loan readiness score out of range: ${score}`);

set('odLoan', 5000000); set('odRate', 8.4); set('odYears', 20); set('odParked', 500000); set('odMonthly', 10000); set('odPremium', 0.25); set('odFee', 0);
window.calcODLoan();
if (window.document.getElementById('odOut').style.display !== 'block') throw new Error('OD comparison did not render.');
if (!/₹/.test(window.document.getElementById('odSaving').textContent)) throw new Error('OD comparison did not produce a saving figure.');

set('apLoan', 1000000); set('apRate', 10); set('apYears', 5); set('apFeePct', 1); set('apGst', 18); set('apInsurance', 15000);
window.calcTrueAPR();
if (!visible('apOut') || Number(window.document.getElementById('apApr').textContent) <= 10) throw new Error('True APR did not expose the fee-adjusted rate.');

set('rsBal', 4000000); set('rsOldRate', 8.4); set('rsNewRate', 9.4); set('rsMonths', 240);
window.calcRateReset();
if (!visible('rsOut')) throw new Error('Rate reset shock did not render.');

set('ulIncome', 100000); set('ulOblig', 20000); set('ulCloseEmi', 5000); set('ulCloseCost', 100000); set('ulFoir', 55); set('ulRate', 8.4); set('ulYears', 20);
window.calcUnlocker();
if (!visible('ulOut')) throw new Error('Eligibility unlocker did not render.');

const debtRows = [...window.document.querySelectorAll('.debtrow')];
[[80000,36,4000],[300000,14,8000],[450000,9,9000]].forEach((values,index) => {
  debtRows[index].querySelector('.debtbal').value = values[0];
  debtRows[index].querySelector('.debtrate').value = values[1];
  debtRows[index].querySelector('.debtmin').value = values[2];
});
set('dpExtra', 5000); window.calcDebtPlan();
if (!visible('dpOut')) throw new Error('Debt payoff strategy did not render.');

set('rbPrice', 8000000); set('rbDown', 2000000); set('rbRate', 8.4); set('rbYears', 20); set('rbHorizon', 10); set('rbRent', 30000);
window.calcRentBuy();
if (!visible('rbOut')) throw new Error('Rent versus buy lab did not render.');

set('piBal', 4000000); set('piRate', 8.4); set('piMonths', 180); set('piAmount', 500000); set('piReturn', 10); set('piTax', 12.5);
window.calcPrepayInvest();
if (!visible('piOut')) throw new Error('Prepay versus invest did not render.');

set('moBal', 1000000); set('moRate', 10); set('moMonths', 60); set('moHoliday', 6);
window.calcMoratoriumTrap();
if (!visible('moOut')) throw new Error('Moratorium cost did not render.');

set('efSpend', 40000); set('efEmi', 20000); set('efCurrent', 120000); set('efSave', 10000); set('efDependents', 3);
window.calcEmergencyFund();
if (!visible('efOut')) throw new Error('Emergency fund architect did not render.');

set('rtAge', 40); set('rtRetire', 60); set('rtLife', 85); set('rtExpense', 60000); set('rtExisting', 1000000);
window.calcRetirement();
if (!visible('rtOut')) throw new Error('Retirement corpus planner did not render.');

set('rrAmount', 500000); set('rrRate', 10); set('rrTax', 12.5); set('rrInfl', 6); set('rrYears', 10);
window.calcRealReturn();
if (!visible('rrOut')) throw new Error('Real-return calculator did not render.');

set('dsIncome', 1500000); set('dsExisting', 240000); set('dsLoan', 3000000); set('dsRate', 11); set('dsYears', 7); set('dsTarget', 1.5);
window.calcDSCR();
if (!visible('dsOut')) throw new Error('DSCR capacity tool did not render.');

window.filterTools('DSCR');
if (!window.document.getElementById('searchMeta').textContent.startsWith('1 matching')) throw new Error('Tool search did not isolate DSCR.');
window.filterTools('');

const homeTiles = window.document.querySelectorAll('#home .tile').length;
if (homeTiles !== 38) throw new Error(`Expected 38 home tools, found ${homeTiles}.`);

console.log(`Smoke-tested the core calculators, all 11 new decision tools, search and ${homeTiles} rendered tools.`);
dom.window.close();
