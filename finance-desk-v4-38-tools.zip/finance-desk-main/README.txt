FINANCE DESK — PWA + ANDROID SOURCE
===================================
A tool made by Chitranjan Sharma

The original PWA remains deployable from the repository root. Android packaging
is powered by Capacitor and a GitHub Actions cloud build, so Android Studio is
not required on your phone.

NEW IN V4.1 — 38 TOOLS
----------------------
• Loan Readiness Lab with FOIR, LTV, credit, emergency-buffer and +2% stress test
• OD / Max-Saving Home Loan comparison with rate-premium and fee modelling
• True Loan APR after fees, GST, insurance and net-disbursal deductions
• Floating-rate Reset Shock: higher EMI versus longer tenure
• Eligibility Unlocker for deciding which running EMI to close
• Debt Freedom Strategy: avalanche versus snowball
• Rent vs Buy Wealth Lab with opportunity cost and future net worth
• Prepay vs Invest with after-tax break-even return
• Moratorium Trap showing capitalised interest and lifetime cost
• Risk-based Emergency Fund Architect
• Inflation-aware Retirement Corpus Planner
• After-Tax Real Return calculator
• DSCR and indicative Business Loan Capacity
• Instant search across every tool
• Shareable loan, readiness and OD summaries
• Private backup and restore for saved loan profiles
• Native Android back-button, status-bar, splash and light haptic feedback
• Visible "V4.1 · 38 TOOLS · VERIFIED BUILD" marker on the home screen

ANDROID APK FROM A PHONE
------------------------
The no-command-line method is documented in PHONE_BUILD_GUIDE.md. It uploads
the complete ZIP as one file, creates one GitHub workflow in the browser, and
returns an installable APK under the workflow's Artifacts section.

The debug APK is for private testing and direct installation. A Play Store
release requires a permanent release signing key and an Android App Bundle.

For a future PWA update, edit index.html and bump CACHE_VERSION in sw.js.
Installed PWA copies refresh on their next online launch.
