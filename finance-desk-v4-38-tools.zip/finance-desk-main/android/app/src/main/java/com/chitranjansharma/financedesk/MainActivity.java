package com.chitranjansharma.financedesk;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
