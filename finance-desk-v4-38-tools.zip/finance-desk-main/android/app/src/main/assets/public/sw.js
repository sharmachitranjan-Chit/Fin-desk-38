/* Finance Desk — service worker (v2, hardened for Cloudflare Pages)
   FLAT layout: icons live at the repo root (no icons/ folder).

   Why v2: the old worker pre-cached the whole shell in one atomic step, so a
   single non-200 response aborted the install and left the cache empty — and
   its page handler could then resolve to `undefined` (a blank page that
   survived reloads). Cloudflare Pages 308-redirects /index.html -> /, which is
   exactly what tripped that atomic step; Vercel doesn't redirect, so the same
   worker happened to work there.

   This version is NETWORK-FIRST for page loads, caches each asset
   INDIVIDUALLY (one bad file can't abort install), and NEVER returns
   `undefined`. Bump CACHE_VERSION whenever you change index.html or an asset. */

const CACHE_VERSION = 'financedesk-v4-1';

const SHELL = [
  './',
  './index.html',
  './manifest.webmanifest',
  './icon-192.png',
  './icon-512.png',
  './icon-maskable-512.png',
  './apple-touch-icon.png',
  './favicon-32.png',
  './favicon-16.png'
];

function offlineShell() {
  return new Response(
    '<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">' +
    '<title>Finance Desk — offline</title>' +
    '<body style="font-family:Georgia,serif;background:#F4EFE8;color:#231E25;margin:0;display:grid;place-items:center;min-height:100vh;text-align:center;padding:24px">' +
    '<div><h1 style="color:#7A1C2A;margin:0 0 8px">Finance Desk</h1>' +
    '<p style="color:#857C88">You appear to be offline and the app has not been cached yet.<br>Reconnect once, then it will work offline.</p></div></body>',
    { headers: { 'Content-Type': 'text/html; charset=utf-8' } }
  );
}

/* Install: precache each file individually so one missing/redirected asset
   (e.g. Cloudflare's /index.html -> / redirect) can't abort the whole install. */
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_VERSION).then((cache) =>
      Promise.all(SHELL.map((url) =>
        cache.add(url).catch((err) => console.warn('[sw] precache skipped:', url, err))
      ))
    ).then(() => self.skipWaiting())
  );
});

/* Activate: drop old caches, take control of open pages immediately so this
   fixed worker replaces any older one. */
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(
        keys.filter((k) => k !== CACHE_VERSION).map((k) => caches.delete(k))
      ))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;

  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;

  /* PAGE LOADS — network-first.
     Online -> freshest index.html (and refresh the offline copy).
     Offline -> cached shell, then a tiny offline page. Never `undefined`. */
  if (req.mode === 'navigate') {
    event.respondWith(
      fetch(req)
        .then((resp) => {
          const copy = resp.clone();
          caches.open(CACHE_VERSION)
            .then((cache) => cache.put('./index.html', copy))
            .catch(() => {});
          return resp;
        })
        .catch(() =>
          caches.match('./index.html')
            .then((cached) => cached || caches.match('./'))
            .then((cached) => cached || offlineShell())
        )
    );
    return;
  }

  /* OTHER GET (icons, manifest) — cache-first with quiet background refresh.
     Always returns a Response. */
  event.respondWith(
    caches.match(req).then((cached) => {
      const network = fetch(req)
        .then((resp) => {
          if (resp && resp.status === 200 && resp.type === 'basic') {
            const copy = resp.clone();
            caches.open(CACHE_VERSION).then((cache) => cache.put(req, copy)).catch(() => {});
          }
          return resp;
        })
        .catch(() => cached || new Response('', { status: 504, statusText: 'offline' }));
      return cached || network;
    })
  );
});

self.addEventListener('message', (event) => {
  if (event.data === 'skipWaiting') self.skipWaiting();
});
